#HOW CHANGE THE ICONS ? 

- Copy your icon picture to folder /TheFatrat/icons ( must *.ico )
- Change the name into autorun.ico 
- And Replace 
- Done 
