Don't Delete the Folder and dont change directory name , if you change you must change the script too 
