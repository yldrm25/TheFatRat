Don't Delete the Folder temp and dont change directory name , if you change you must change the scripttoo 
