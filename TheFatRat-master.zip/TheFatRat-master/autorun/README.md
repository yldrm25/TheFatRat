
#Autorun 

- Autorun work if the victim disabled uac ( user acces control ) or low uac ( WINDOWS ) 
- What is uac ? you can visit ( http://www.digitalcitizen.life/uac-why-you-should-never-turn-it-off ) 
- I have also created 3 AutoRun files
- Simply copy these files to a CD or USB
- You can change the icon autorun file or exe in folder icon ( replace your another ico and replace name with autorun.ico )
