## CHANGELOG

* v1.7 - add backdoor ( rar files )
* v1.7 - Add backdoor ( doc not macro attack)
* v1.7 - Add new features in optional 1 ( create backdoor with msfvenom )
* v1.7 - Fix any bug 
* v1.6 - Add new features create backdoor with PwnWinds ( FUD++ )
* v1.6 - Add some script for checking monodevelop and apache server
* v1.6 - Add new features backdooring original apk with metasploit
* v1.6 - Add setup.sh for configuration fatrat and install dependencies
* v1.6 - remove auto install bdf and mingw ( funciton checked )
* v1.6 - Add listener for android 
* v1.6 - Add feature for cleanup all backdoor 
* v1.5 - Add featrues embed backdoor with backdoor-factory
* v1.5 - Recoded fucntion cmsfvenom
* v1.5 - add feature exit ( auto stop service apache and metasploit )
* v1.5 - Add some Variables ( pwd , Version ,Codename )
* v1.5 - Added script function gboor ( checked if your command is correct)
* v1.5 - Added script function spinner for randoom seed generator from avoid
* v1.5 - Added script function spinner metasploit generator from avoid
* V1.5 - Added autorun script when create listener
* v1.5 - Remove cd "output"
* v1.5 - Change the script ouput when msfvenom create
* v1.4 - Fixed fatrat ( cd output not found )
* v1.4 - Fixed powerfull.sh
* v1.4 - Fixed fatrat
* v1.4 - Change autorun icons with icon avira
* v1.3 - Fixed Code ( backdoor apk in option 1 )
* v1.2 - Added msfvenom multi encoders option 1 ( for windows ) ( with 5 encoders )
* v1.2 - Added msfvenom multi encodersin optiion 1 ( For Windows ) ( with two encoders )
* V1.2 - Added script automated install gcc in fatrat
* v1.1 - Added New Feature ( Create Backdoor With Avoid )
* v1.1 - Add multi encoder in msfvenom
* v1.1 - Fixed Bug
* v1.0 - Release TheFatRat
