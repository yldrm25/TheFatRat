
 

#TheFatRat ( Unit for bypass av )

##Update: Version 1.7 
##Codename: Keris 

What is TheFatRat ?? 

An easy tool to generate backdoor with msfvenom (a part from metasploit framework). This tool compiles a malware with popular payload and then the compiled malware can be execute on windows, android, mac . The malware that created with this tool also have an ability to bypass most AV software protection

#Screenshot
<img src="https://cloud.githubusercontent.com/assets/17976841/18483842/1f5057b2-7a10-11e6-95db-1320e83beac3.png" width="55%"></img> 
#---------------------------------------------------------------

<img src="https://cloud.githubusercontent.com/assets/17976841/18483870/39cb46ba-7a10-11e6-859b-1c1baa3c1b0a.png" width="32%"></img> <img src="https://cloud.githubusercontent.com/assets/17976841/18483871/39cb81ca-7a10-11e6-84f3-1683067fa4f5.png" width="32%"></img> <img src="https://cloud.githubusercontent.com/assets/17976841/18483873/39d54372-7a10-11e6-890f-41803a33b9c9.png" width="32%"></img> 
#Automating metasploit functions 

- Checks for metasploit service and starts if not present

- Easily craft meterpreter reverse_tcp payloads for Windows, Linux, Android and Mac and another

- Start multiple meterpreter reverse_tcp listners 

- Fast Search in searchsploit

- Bypass AV

- Create backdoor with another techniq

- Autorunscript for listeners ( easy to use )

- Drop into Msfconsole

- Some other fun stuff :)



#Autorun Backdoor

- Autorun work if the victim disabled uac ( user acces control ) or low uac ( WINDOWS ) 
- What is uac ? you can visit ( http://www.digitalcitizen.life/uac-why-you-should-never-turn-it-off ) 
- I have also created 3 AutoRun files
- Simply copy these files to a CD or USB
- You can change the icon autorun file or exe in folder icon ( replace your another ico and replace name with autorun.ico )


#HOW CHANGE THE ICONS ? 

- Copy your icon picture to folder /TheFatrat/icons
- Change the name into autorun.ico 
- And Replace 
- Done 


## :scroll: Changelog
Be sure to check out the [Changelog] and Read CHANGELOG.md


## Getting Started
1. ```git clone https://github.com/Screetsec/TheFatRat.git```
2. ```cd TehFatrat/Setup```
3. ```chmod +x setup.sh && ./setup.sh```

 
## :book: How it works

* Extract The lalin-master to your home or another folder
* chmod +x fatrat
* chmod +x powerfull.sh
* And run the tools ( ./fatrat )
* Easy to Use just input your number


##  :heavy_exclamation_mark: Requirements

- A linux operating system. We recommend Kali Linux 2 or Kali 2016.1 rolling / Cyborg / Parrot / Dracos / BackTrack / Backbox / and another operating system ( linux ) 

- Must install metasploit framework 



##  :heavy_exclamation_mark: READ
- if prog.c file to large when create backdoor with powerfull.sh , you can use prog.c.backup and create another backup when you running option 2


## Tutorial ? 

you can visit my channel  : https://www.youtube.com/channel/UCpK9IXzLMfVFp9NUfDzxFfw

## BUG ? 

- Submit new issue 
- pm me
- Hey sup ? do you want ask about all my tools ? you can join me in telegram.me/offscreetsec


## :octocat: Credits

- Thanks to allah and Screetsec [ Edo -maland- ] <Me> 
- Dracos Linux from Scratch Indonesia ( Penetration os ) Thanksyou , you can see in http://dracos-linux.org/ 
- Offensive Security for the awesome OS ( http://www.offensive-security.com/ )
- http://www.kali.org/"   
- Jack Wilder admin in http://www.linuxsec.org
- And another open sources tool in github
- Uptodate new tools hacking visit http://www.kitploit.com

## Disclaimer

***Note: modifications, changes, or alterations to this sourcecode is acceptable, however,any public releases utilizing this code must be approved by writen this tool ( Edo -m- ).***

